For the demo I used a very old version of Windows and Edge because the AppContainer sandbox actually let a child process survive long enough to be seen in the process list

The actual renderer bug can be exploited up to versions from January 2019

I did write an exploit for a more recent version of Windows, but the capabilities sanbox would interrupt WinExec without spawning the child process