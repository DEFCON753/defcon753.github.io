This folder containes the solution to the CTF Challenge

To run the challenge binary you need to create a writeable folder at /home/ctf/tmp/

The challenge binary reads a null terminated js file from stdin