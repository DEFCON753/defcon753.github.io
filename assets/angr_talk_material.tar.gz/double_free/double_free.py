import angr

class CheckedFree(angr.SimProcedure):
	def run(self, ptr):
		if self.state.solver.is_true(ptr == 0):
			return

		if 'free_chunks' not in self.state.globals:
			self.state.globals['free_chunks'] = []

		df_conds = [ptr == free_ptr for free_ptr in self.state.globals['free_chunks']]
		extra_constraints = (self.state.solver.Or(*df_conds), ptr != 0)
		
		if self.state.solver.satisfiable(extra_constraints=extra_constraints):
			payload = self.state.posix.dumps(0, extra_constraints=extra_constraints)
			print ('FOUND double free: {}'.format(payload))

		self.state.globals['free_chunks'].append(ptr)


project = angr.Project("./test", load_options={'auto_load_libs': False})

project.hook_symbol('free', CheckedFree())

simgr = project.factory.simulation_manager()
simgr.run()
