#include <stdlib.h>
#include <unistd.h>

void *bufs[10];

int read_digit()
{
	char digit = 0;
	read(0, &digit, 1);
	if (digit < '0' || digit > '9')
		exit(1);
	return digit - '0';
}

int main()
{
	char choice;

	while (1) {
		choice = 0;
		read(0, &choice, 1);
		switch(choice) {
			case 'a':
				bufs[read_digit()] = malloc(32);
				break;
			case 'f':
				free(bufs[read_digit()]);
				break;
			default:
				exit(0);
		}
	}
}
