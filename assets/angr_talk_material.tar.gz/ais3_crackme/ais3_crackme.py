import angr
import claripy

try: bytes
except: bytes = str

project = angr.Project("./ais3_crackme", auto_load_libs=False)

sym = claripy.BVS("sym", 100*8)
state = project.factory.full_init_state(args=("./ais3_rackme", sym))

simgr = project.factory.simulation_manager(state)
simgr.explore(find=0x00400602, avoid=0x0040060e)

print("solution find/avoid:", simgr.found[0].solver.eval(sym, cast_to=bytes))

simgr = project.factory.simulation_manager(state)
simgr.explore(find=lambda s: b"Correct" in s.posix.dumps(1))

print("solution using lambda:", simgr.found[0].solver.eval(sym, cast_to=bytes))

