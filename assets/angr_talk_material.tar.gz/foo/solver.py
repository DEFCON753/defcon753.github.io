import angr
# load the example
project = angr.Project("./foo")

# start a new SimulationManager
simgr = project.factory.simulation_manager()
# step
simgr.step()
# step until it branches
simgr.run(until=lambda sm: len(sm.active) != 1)
# check the states that are still active
print (simgr.active)

state = simgr.active[0]

# SMT solver
print (state.solver)
addr = state.regs.rsp + 0x100
# each value in angr is represented as an expression tree
v = state.memory.load(addr, 8) + 0x10
print (v)
print (v.op) # __add__
print (v.args) # (other bitvector, 0x10)
# add state constraints
state.add_constraints(v < 0x2a)
state.add_constraints(v > 0x1a)
# concretize a value
print (hex(state.solver.eval(v)))
