#include <stdio.h>

int foo(int a, int b)
{
    int c = 77;

    if(a + b == 42) {
        c = c - b;
    }
    else {
        c = a - c;
    }
    if(c == 38) {
        puts("Well done.");
    }
    else {
        puts("Try again.");
    }
}

int main()
{
    int a, b;
    scanf("%d", &a);
    scanf("%d", &b);
    
    foo(a, b);
}
