import angr
# load the example
project = angr.Project("./foo")

# start a new SimulationManager
simgr = project.factory.simulation_manager()
# step
simgr.step()
# step until it branches
simgr.run(until=lambda sm: len(sm.active) != 1)
# check the states that are still active
print (simgr.active)

state = simgr.active[0]

# a state has plugins, representing registers, memory, etc
print (state.regs.rax)
print (state.memory.load(state.regs.rsp, 8))
# one of the plugins represents the system state
print (state.posix.fd)
# files are backed by a memory region
print (state.posix.fd[0].read_data(8)) #return (value, size)

