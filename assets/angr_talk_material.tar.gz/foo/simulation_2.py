import angr
# load the example
project = angr.Project("./foo")

# create a state starting on foo()
initial_state = project.factory.blank_state()
initial_state.regs.rip = 0x4005c7 # foo address
# create symbolic args
a = initial_state.solver.BVS("sym_a", 64)
b = initial_state.solver.BVS("sym_b", 64)
initial_state.regs.rdi = a
initial_state.regs.rsi = b
# start a new SimulationManager based on initial_state
simgr = project.factory.simulation_manager(initial_state)
# explore using conditions
simgr.explore(find=0x400600, avoid=0x40060e) # well done, try again 
print (simgr, simgr.found) # found stash
# conretize found inputs
print (a.args[0], "=", simgr.found[0].solver.eval(a))
print (b.args[0], "=", simgr.found[0].solver.eval(b))
