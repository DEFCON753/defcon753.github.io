
/*! @file
 *  This is an example of the PIN tool that demonstrates some basic PIN APIs 
 *  and could serve as the starting point for developing your first PIN tool
 */

#include "pin.H"
#include <iostream>
#include <string.h>
using namespace std;

typedef const wchar_t* LPCWSTR;

#define GET_LPCSTR(c, buf, bufSize)	do { \
			size_t i; \
			for (i = 0; i < bufSize; i++) { \
				(buf)[i] = (c)[2*i]; \
				if ((c)[2*i] == '\0') break; \
			} \
} while (0)

/* ================================================================== */
// Global variables 
/* ================================================================== */

UINT64 insCount = 0;        //number of dynamically executed instructions
int cont = 0;

/* ===================================================================== */
// Utilities
/* ===================================================================== */

/*!
 *  Print out help message.
 */
INT32 Usage()
{
    cout << "This tool prints out the number of dynamically executed " << endl <<
            "instructions, basic blocks and threads in the application." << endl << endl;

    return -1;
}

/* ===================================================================== */
// Auxiliary routines
/* ===================================================================== */

void CreateFileHook(LPCWSTR *fileName) {

	char value[200];
	GET_LPCSTR((char*)*fileName, value, 200);
	cout << "File " << value << endl;

	*fileName = L"C:\\tmp2.txt";

}

/* ===================================================================== */
// Analysis routines
/* ===================================================================== */

// trigger the instrumentation routine(s) for each instruction
static void InstrumentInstruction(INS ins, void *v) {
	
	insCount++;

}

// trigger the instrumentation routine(s) for each routines
static VOID InstrumentRoutine(RTN rtn, VOID *) {

	if (RTN_Name(rtn).compare("CreateFileW") == 0 && cont == 0) {

		cont++;

		const char* rtnName = RTN_Name(rtn).c_str();
		cout << "Library call " << RTN_Name(rtn).c_str() << " found!" << endl;

		RTN_Open(rtn);

		RTN_InsertCall(rtn, IPOINT_BEFORE, (AFUNPTR)CreateFileHook,
			IARG_FUNCARG_ENTRYPOINT_REFERENCE, 0,
			IARG_END);
		
		RTN_Close(rtn);

	}

}

/*!
 * Print out analysis results.
 * This function is called when the application exits.
 * @param[in]   code            exit code of the application
 * @param[in]   v               value specified by the tool in the 
 *                              PIN_AddFiniFunction function call
 */
VOID Fini(INT32 code, VOID *v)
{
    cout <<  "===============================================" << endl;
	cout <<  "MyPinTool analysis results: " << endl;
	cout <<  "Number of instructions: " << insCount  << endl;
	cout <<  "===============================================" << endl;
}

/*!
 * The main procedure of the tool.
 * This function is called when the application image is loaded but not yet started.
 * @param[in]   argc            total number of elements in the argv array
 * @param[in]   argv            array of command line arguments, 
 *                              including pin -t <toolname> -- ...
 */
int main(int argc, char *argv[])
{
    // Initialize PIN library. Print help message if -h(elp) is specified
    // in the command line or the command line is invalid 
	PIN_InitSymbols();
    if( PIN_Init(argc,argv) ) {
        return Usage();
    }

	// Register function to be called when instructions execute
	INS_AddInstrumentFunction(InstrumentInstruction, nullptr);

	// Register function to be called when routines execute
	RTN_AddInstrumentFunction(InstrumentRoutine, nullptr);

    // Register function to be called when the application exits
    PIN_AddFiniFunction(Fini, 0);
    
    
	cout <<  "===============================================" << endl;
	cout <<  "This application is instrumented by MyPinTool" << endl;
	cout <<  "===============================================" << endl;

    // Start the program, never returns
    PIN_StartProgram();
    
    return 0;
}

/* ===================================================================== */
/* eof */
/* ===================================================================== */
